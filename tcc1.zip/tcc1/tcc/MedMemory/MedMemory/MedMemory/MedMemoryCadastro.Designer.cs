﻿namespace MedMemory
{
    partial class MedMemoryCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MedMemoryCadastro));
            this.pnMensagem = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btCad = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.LbErro = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.pbNome = new System.Windows.Forms.PictureBox();
            this.btCadastrar = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.pbEmail = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.pbSenha = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picIco = new System.Windows.Forms.PictureBox();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.pbUsuario = new System.Windows.Forms.PictureBox();
            this.pnMensagem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSenha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIco)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUsuario)).BeginInit();
            this.SuspendLayout();
            // 
            // pnMensagem
            // 
            this.pnMensagem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(52)))));
            this.pnMensagem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnMensagem.Controls.Add(this.label1);
            this.pnMensagem.Controls.Add(this.btCad);
            this.pnMensagem.Location = new System.Drawing.Point(28, 130);
            this.pnMensagem.Name = "pnMensagem";
            this.pnMensagem.Size = new System.Drawing.Size(265, 113);
            this.pnMensagem.TabIndex = 64;
            this.pnMensagem.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(14, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cadastro concluído\r\nObrigado por se cadastrar!";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btCad
            // 
            this.btCad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btCad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btCad.FlatAppearance.BorderSize = 0;
            this.btCad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCad.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCad.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btCad.Location = new System.Drawing.Point(92, 75);
            this.btCad.Name = "btCad";
            this.btCad.Size = new System.Drawing.Size(75, 30);
            this.btCad.TabIndex = 1;
            this.btCad.Text = "OK!";
            this.btCad.UseVisualStyleBackColor = false;
            this.btCad.Click += new System.EventHandler(this.btCad_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.ForeColor = System.Drawing.Color.IndianRed;
            this.label2.Location = new System.Drawing.Point(295, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 13);
            this.label2.TabIndex = 65;
            this.label2.Text = "X";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // LbErro
            // 
            this.LbErro.AutoSize = true;
            this.LbErro.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbErro.ForeColor = System.Drawing.Color.IndianRed;
            this.LbErro.Location = new System.Drawing.Point(83, 291);
            this.LbErro.Name = "LbErro";
            this.LbErro.Size = new System.Drawing.Size(171, 16);
            this.LbErro.TabIndex = 63;
            this.LbErro.Text = "Preencher todos os campos";
            this.LbErro.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel4.Location = new System.Drawing.Point(28, 160);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(265, 1);
            this.panel4.TabIndex = 62;
            // 
            // txtNome
            // 
            this.txtNome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtNome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNome.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.txtNome.Location = new System.Drawing.Point(76, 139);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(217, 19);
            this.txtNome.TabIndex = 49;
            this.txtNome.Text = "Nome";
            this.txtNome.Click += new System.EventHandler(this.txtNome_Click);
            // 
            // pbNome
            // 
            this.pbNome.BackColor = System.Drawing.Color.Transparent;
            this.pbNome.Image = global::MedMemory.Properties.Resources.perfil1;
            this.pbNome.Location = new System.Drawing.Point(31, 129);
            this.pbNome.Name = "pbNome";
            this.pbNome.Size = new System.Drawing.Size(39, 28);
            this.pbNome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbNome.TabIndex = 61;
            this.pbNome.TabStop = false;
            // 
            // btCadastrar
            // 
            this.btCadastrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btCadastrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btCadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCadastrar.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCadastrar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btCadastrar.Location = new System.Drawing.Point(28, 310);
            this.btCadastrar.Name = "btCadastrar";
            this.btCadastrar.Size = new System.Drawing.Size(265, 41);
            this.btCadastrar.TabIndex = 60;
            this.btCadastrar.Text = "Cadastrar";
            this.btCadastrar.UseVisualStyleBackColor = false;
            this.btCadastrar.Click += new System.EventHandler(this.btCadastrar_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel3.Location = new System.Drawing.Point(28, 283);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(265, 1);
            this.panel3.TabIndex = 59;
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmail.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.txtEmail.Location = new System.Drawing.Point(76, 261);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(217, 19);
            this.txtEmail.TabIndex = 52;
            this.txtEmail.Text = "Email";
            this.txtEmail.Click += new System.EventHandler(this.txtEmail_Click);
            // 
            // pbEmail
            // 
            this.pbEmail.BackColor = System.Drawing.Color.Transparent;
            this.pbEmail.Image = ((System.Drawing.Image)(resources.GetObject("pbEmail.Image")));
            this.pbEmail.Location = new System.Drawing.Point(38, 261);
            this.pbEmail.Name = "pbEmail";
            this.pbEmail.Size = new System.Drawing.Size(27, 19);
            this.pbEmail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEmail.TabIndex = 58;
            this.pbEmail.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Location = new System.Drawing.Point(28, 242);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(265, 1);
            this.panel2.TabIndex = 57;
            // 
            // txtSenha
            // 
            this.txtSenha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSenha.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSenha.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.txtSenha.Location = new System.Drawing.Point(76, 220);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.Size = new System.Drawing.Size(217, 19);
            this.txtSenha.TabIndex = 51;
            this.txtSenha.Text = "Senha";
            this.txtSenha.Click += new System.EventHandler(this.txtSenha_Click);
            // 
            // pbSenha
            // 
            this.pbSenha.BackColor = System.Drawing.Color.Transparent;
            this.pbSenha.Image = global::MedMemory.Properties.Resources.cadeado1;
            this.pbSenha.Location = new System.Drawing.Point(31, 208);
            this.pbSenha.Name = "pbSenha";
            this.pbSenha.Size = new System.Drawing.Size(37, 31);
            this.pbSenha.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSenha.TabIndex = 56;
            this.pbSenha.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.Location = new System.Drawing.Point(28, 201);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(265, 1);
            this.panel1.TabIndex = 55;
            // 
            // picIco
            // 
            this.picIco.BackColor = System.Drawing.Color.Black;
            this.picIco.Location = new System.Drawing.Point(111, 31);
            this.picIco.Name = "picIco";
            this.picIco.Size = new System.Drawing.Size(104, 63);
            this.picIco.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picIco.TabIndex = 54;
            this.picIco.TabStop = false;
            // 
            // txtUsuario
            // 
            this.txtUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtUsuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUsuario.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuario.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.txtUsuario.Location = new System.Drawing.Point(76, 179);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(217, 19);
            this.txtUsuario.TabIndex = 50;
            this.txtUsuario.Text = "Usuário";
            this.txtUsuario.Click += new System.EventHandler(this.txtUsuario_Click);
            // 
            // pbUsuario
            // 
            this.pbUsuario.BackColor = System.Drawing.Color.Transparent;
            this.pbUsuario.Image = global::MedMemory.Properties.Resources.perfil1;
            this.pbUsuario.Location = new System.Drawing.Point(31, 170);
            this.pbUsuario.Name = "pbUsuario";
            this.pbUsuario.Size = new System.Drawing.Size(39, 28);
            this.pbUsuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbUsuario.TabIndex = 53;
            this.pbUsuario.TabStop = false;
            // 
            // MedMemoryCadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(321, 383);
            this.Controls.Add(this.pnMensagem);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LbErro);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.pbNome);
            this.Controls.Add(this.btCadastrar);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.pbEmail);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtSenha);
            this.Controls.Add(this.pbSenha);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.picIco);
            this.Controls.Add(this.txtUsuario);
            this.Controls.Add(this.pbUsuario);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MedMemoryCadastro";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MedMemoryCadastro";
            this.pnMensagem.ResumeLayout(false);
            this.pnMensagem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSenha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIco)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUsuario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnMensagem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btCad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LbErro;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.PictureBox pbNome;
        private System.Windows.Forms.Button btCadastrar;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.PictureBox pbEmail;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.PictureBox pbSenha;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox picIco;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.PictureBox pbUsuario;
    }
}