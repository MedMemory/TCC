﻿using MedMemory.Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedMemory
{
    public partial class MedMemoryCadastro : Form
    {
        Login usuario;
        public MedMemoryCadastro()
        {
            InitializeComponent();
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {
            usuario = new Login();
            usuario.setNome(txtNome.Text);
            usuario.setUsuario(txtUsuario.Text);
            usuario.setEmail(txtEmail.Text);
            usuario.setSenha(txtSenha.Text);
            if (txtNome.Text.Trim() == string.Empty || txtSenha.Text.Trim() == string.Empty || txtEmail.Text.Trim() == string.Empty || txtUsuario.Text.Trim() == string.Empty)
            {
                LbErro.Visible = true;
            }
            else
            {
                pnMensagem.Visible = true;
                LbErro.Visible = false;
            }
            MedMemoryLogin.usuario = usuario;
        }

        private void btCad_Click(object sender, EventArgs e)
        {
            LbErro.Visible = false;
            pnMensagem.Visible = false;
            this.Dispose();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Close();
        }

        //personalização
        //Cadastro
        private void txtNome_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            panel4.BackColor = Color.FromArgb(38, 184, 206);
            txtNome.ForeColor = Color.FromArgb(38, 184, 206);
            pbNome.Image = Properties.Resources.perfil2;


            panel2.BackColor = SystemColors.ButtonFace;
            txtSenha.ForeColor = SystemColors.ButtonFace;
            pbSenha.Image = Properties.Resources.cadeado1;

            panel1.BackColor = SystemColors.ButtonFace;
            txtUsuario.ForeColor = SystemColors.ButtonFace;
            pbUsuario.Image = Properties.Resources.perfil1;

            panel3.BackColor = SystemColors.ButtonFace;
            txtEmail.ForeColor = SystemColors.ButtonFace;
            pbEmail.Image = Properties.Resources.Email1;
        }

        private void txtUsuario_Click(object sender, EventArgs e)
        {
            txtUsuario.Clear();
            panel1.BackColor = Color.FromArgb(38, 184, 206);
            txtUsuario.ForeColor = Color.FromArgb(38, 184, 206);
            pbUsuario.Image = Properties.Resources.perfil2;


            panel2.BackColor = SystemColors.ButtonFace;
            txtSenha.ForeColor = SystemColors.ButtonFace;
            pbSenha.Image = Properties.Resources.cadeado1;

            panel3.BackColor = SystemColors.ButtonFace;
            txtEmail.ForeColor = SystemColors.ButtonFace;
            pbEmail.Image = Properties.Resources.Email1;

            panel4.BackColor = SystemColors.ButtonFace;
            txtNome.ForeColor = SystemColors.ButtonFace;
            pbNome.Image = Properties.Resources.perfil1;
        }

        private void txtSenha_Click(object sender, EventArgs e)
        {
            txtSenha.Clear();
            panel2.BackColor = Color.FromArgb(38, 184, 206);
            txtSenha.ForeColor = Color.FromArgb(38, 184, 206);
            pbSenha.Image = Properties.Resources.cadeado2;


            panel1.BackColor = SystemColors.ButtonFace;
            txtUsuario.ForeColor = SystemColors.ButtonFace;
            pbUsuario.Image = Properties.Resources.perfil1;

            panel3.BackColor = SystemColors.ButtonFace;
            txtEmail.ForeColor = SystemColors.ButtonFace;
            pbEmail.Image = Properties.Resources.Email1;

            panel4.BackColor = SystemColors.ButtonFace;
            txtNome.ForeColor = SystemColors.ButtonFace;
            pbNome.Image = Properties.Resources.perfil1;
        }

        private void txtEmail_Click(object sender, EventArgs e)
        {
            txtEmail.Clear();
            panel3.BackColor = Color.FromArgb(38, 184, 206);
            txtEmail.ForeColor = Color.FromArgb(38, 184, 206);
            pbEmail.Image = Properties.Resources.Email2;

            panel4.BackColor = SystemColors.ButtonFace;
            txtNome.ForeColor = SystemColors.ButtonFace;
            pbNome.Image = Properties.Resources.perfil1;

            panel1.BackColor = SystemColors.ButtonFace;
            txtUsuario.ForeColor = SystemColors.ButtonFace;
            pbUsuario.Image = Properties.Resources.perfil1;

            panel2.BackColor = SystemColors.ButtonFace;
            txtSenha.ForeColor = SystemColors.ButtonFace;
            pbSenha.Image = Properties.Resources.cadeado1;
        }
    }
}
