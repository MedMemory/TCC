﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedMemory.Entidades
{
    public class Alarme
    {
        //string nome;
        string medicamento;
        string forma;
        string dosagem;
        float quantidade;
        TimeSpan horario;
        private bool ativo;

        /*public void setNome(string _nome)
        {
            nome = _nome;
        }

        public string getNome()
        {
            return nome;
        }*/

        public void setMedicamento(string _medic)
        {
            medicamento = _medic;
        }
        public string getMedicamento()
        {
            return medicamento;
        }

        public void setForma(string _forma)
        {
            forma = _forma;
        }
        public string getForma()
        {
            return forma;
        }

        public void setDosagem(string _dose)
        {
            dosagem = _dose;
        }
        public string getDosagem()
        {
            return dosagem;
        }

        public void setQuantidade(float _quant)
        {
            quantidade = _quant;
        }
        public float getQantidade()
        {
            return quantidade;
        }

        public void setHorario(TimeSpan _horario)
        {
            horario = _horario;
        }
        public TimeSpan getHorario()
        {
            return horario;
        }

        public string usuario()
        {
            string mostrar = /*"nome: " + nome +*/
                "\nmedicamento: " + medicamento +
                "\nforma: " + forma +
                "\nquantidade: " + quantidade + " " + dosagem;
            mostrar += "\nhorario: " + horario.ToString(@"hh\:mm");
            return mostrar;
        }
        public bool getAtivo()
        {
            return ativo;
        }
        public void setAtivo(bool _Ativo)
        {
            ativo = _Ativo;
        }
    }
}
