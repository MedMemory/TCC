﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedMemory.Entidades
{
    public class Login
    {
        //usuario
        private string usuario;
        public void setUsuario(string _usuario)
        {
            usuario = _usuario;
        }
        public string getUsuario()
        {
            return usuario;
        }

        //senha
        private string senha;
        public void setSenha(string _senha)
        {
            senha = _senha;
        }
        public string getSenha()
        {
            return senha;
        }


        //email
        private string email;
        public void setEmail(string _email)
        {
            email = _email;
        }
        public string getEmail()
        {
            return email;
        }


        //nome
        private string nome;
        public void setNome(string _nome)
        {
            nome = _nome;
        }
        public string getNome()
        {
            return nome;
        }

        //enviar
        public string Usuario()
        {
            string lgUsuario = usuario;
            return lgUsuario;
        }
        public string Senha()
        {
            string lgSenha = senha;
            return lgSenha;
        }
    }
}
