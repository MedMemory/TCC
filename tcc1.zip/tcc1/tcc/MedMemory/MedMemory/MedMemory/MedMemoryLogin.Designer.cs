﻿namespace MedMemory
{
    partial class MedMemoryLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label3 = new System.Windows.Forms.Label();
            this.btRegistrar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textsenha = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textusuario = new System.Windows.Forms.TextBox();
            this.lberro2 = new System.Windows.Forms.Label();
            this.pcsenha = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pcusuario = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pcsenha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcusuario)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.ForeColor = System.Drawing.Color.IndianRed;
            this.label3.Location = new System.Drawing.Point(295, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 13);
            this.label3.TabIndex = 63;
            this.label3.Text = "X";
            this.label3.Click += new System.EventHandler(this.label2_Click);
            // 
            // btRegistrar
            // 
            this.btRegistrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btRegistrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btRegistrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btRegistrar.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btRegistrar.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.btRegistrar.Location = new System.Drawing.Point(28, 298);
            this.btRegistrar.Name = "btRegistrar";
            this.btRegistrar.Size = new System.Drawing.Size(265, 41);
            this.btRegistrar.TabIndex = 62;
            this.btRegistrar.Text = "Registrar";
            this.btRegistrar.UseVisualStyleBackColor = false;
            this.btRegistrar.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.button1.Location = new System.Drawing.Point(28, 249);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(265, 41);
            this.button1.TabIndex = 61;
            this.button1.Text = "Entrar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.panel6.Location = new System.Drawing.Point(28, 209);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(265, 1);
            this.panel6.TabIndex = 60;
            // 
            // textsenha
            // 
            this.textsenha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textsenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textsenha.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textsenha.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.textsenha.Location = new System.Drawing.Point(76, 187);
            this.textsenha.Name = "textsenha";
            this.textsenha.Size = new System.Drawing.Size(217, 19);
            this.textsenha.TabIndex = 55;
            this.textsenha.Text = "Senha";
            this.textsenha.Click += new System.EventHandler(this.textsenha_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel7.Location = new System.Drawing.Point(28, 148);
            this.panel7.Margin = new System.Windows.Forms.Padding(0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(265, 1);
            this.panel7.TabIndex = 58;
            // 
            // textusuario
            // 
            this.textusuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textusuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textusuario.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textusuario.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.textusuario.Location = new System.Drawing.Point(76, 125);
            this.textusuario.Name = "textusuario";
            this.textusuario.Size = new System.Drawing.Size(217, 19);
            this.textusuario.TabIndex = 54;
            this.textusuario.Text = "Usuário";
            this.textusuario.Click += new System.EventHandler(this.textusuario_Click);
            // 
            // lberro2
            // 
            this.lberro2.AutoSize = true;
            this.lberro2.BackColor = System.Drawing.Color.Transparent;
            this.lberro2.ForeColor = System.Drawing.Color.IndianRed;
            this.lberro2.Location = new System.Drawing.Point(92, 213);
            this.lberro2.Name = "lberro2";
            this.lberro2.Size = new System.Drawing.Size(143, 26);
            this.lberro2.TabIndex = 65;
            this.lberro2.Text = "Usuário não existe.\r\nVerifique e tente novamente.";
            this.lberro2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lberro2.Visible = false;
            // 
            // pcsenha
            // 
            this.pcsenha.BackColor = System.Drawing.Color.Transparent;
            this.pcsenha.Image = global::MedMemory.Properties.Resources.cadeado1;
            this.pcsenha.Location = new System.Drawing.Point(28, 171);
            this.pcsenha.Name = "pcsenha";
            this.pcsenha.Size = new System.Drawing.Size(37, 31);
            this.pcsenha.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcsenha.TabIndex = 59;
            this.pcsenha.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Black;
            this.pictureBox6.Location = new System.Drawing.Point(111, 31);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(104, 63);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 57;
            this.pictureBox6.TabStop = false;
            // 
            // pcusuario
            // 
            this.pcusuario.BackColor = System.Drawing.Color.Transparent;
            this.pcusuario.Image = global::MedMemory.Properties.Resources.perfil1;
            this.pcusuario.Location = new System.Drawing.Point(28, 116);
            this.pcusuario.Name = "pcusuario";
            this.pcusuario.Size = new System.Drawing.Size(39, 28);
            this.pcusuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcusuario.TabIndex = 56;
            this.pcusuario.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 40;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 40;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // MedMemoryLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(321, 383);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btRegistrar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.textsenha);
            this.Controls.Add(this.pcsenha);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.textusuario);
            this.Controls.Add(this.pcusuario);
            this.Controls.Add(this.lberro2);
            this.ForeColor = System.Drawing.Color.Transparent;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MedMemoryLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MedMemoryLogin";
            this.Load += new System.EventHandler(this.MedMemoryLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcsenha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcusuario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btRegistrar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textsenha;
        private System.Windows.Forms.PictureBox pcsenha;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox textusuario;
        private System.Windows.Forms.PictureBox pcusuario;
        private System.Windows.Forms.Label lberro2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}