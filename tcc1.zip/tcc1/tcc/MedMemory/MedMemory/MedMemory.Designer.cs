﻿namespace MedMemory
{
    partial class MedMemory
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btPerfil = new System.Windows.Forms.Button();
            this.BtNovoAlarme = new System.Windows.Forms.Button();
            this.LbRelogio = new System.Windows.Forms.Label();
            this.PnNovoAlarme = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtHorario = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.txtQnt = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdComp = new System.Windows.Forms.RadioButton();
            this.rdMl = new System.Windows.Forms.RadioButton();
            this.rdGota = new System.Windows.Forms.RadioButton();
            this.rdColher = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdGasosa = new System.Windows.Forms.RadioButton();
            this.rdSemiLiquido = new System.Windows.Forms.RadioButton();
            this.rdLiquido = new System.Windows.Forms.RadioButton();
            this.rdSolido = new System.Windows.Forms.RadioButton();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.txtMedic = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.pnPerfil = new System.Windows.Forms.Panel();
            this.btmostrar = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbAlarme = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Lbemail = new System.Windows.Forms.Label();
            this.LbUsuario = new System.Windows.Forms.Label();
            this.LbNome = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.Relogio = new System.Windows.Forms.Timer(this.components);
            this.button5 = new System.Windows.Forms.Button();
            this.pnConfig = new System.Windows.Forms.Panel();
            this.pnMenu = new System.Windows.Forms.Panel();
            this.Fechar = new System.Windows.Forms.Label();
            this.Minimizar = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.panel1.SuspendLayout();
            this.PnNovoAlarme.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pnPerfil.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox12.Location = new System.Drawing.Point(12, 103);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(200, 10);
            this.pictureBox12.TabIndex = 33;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox13.Location = new System.Drawing.Point(0, 103);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(16, 151);
            this.pictureBox13.TabIndex = 34;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox11.Location = new System.Drawing.Point(12, 251);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(200, 10);
            this.pictureBox11.TabIndex = 32;
            this.pictureBox11.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btPerfil);
            this.panel1.Controls.Add(this.BtNovoAlarme);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(12, 103);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 151);
            this.panel1.TabIndex = 31;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.button4.Location = new System.Drawing.Point(9, 114);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 27);
            this.button4.TabIndex = 5;
            this.button4.TabStop = false;
            this.button4.Text = "Menu";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.button1.Location = new System.Drawing.Point(9, 81);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 27);
            this.button1.TabIndex = 3;
            this.button1.TabStop = false;
            this.button1.Text = "Configurações";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btPerfil
            // 
            this.btPerfil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btPerfil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPerfil.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btPerfil.Location = new System.Drawing.Point(9, 48);
            this.btPerfil.Name = "btPerfil";
            this.btPerfil.Size = new System.Drawing.Size(100, 27);
            this.btPerfil.TabIndex = 4;
            this.btPerfil.TabStop = false;
            this.btPerfil.Text = "Perfil";
            this.btPerfil.UseVisualStyleBackColor = false;
            this.btPerfil.Click += new System.EventHandler(this.btPerfil_Click);
            // 
            // BtNovoAlarme
            // 
            this.BtNovoAlarme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.BtNovoAlarme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtNovoAlarme.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.BtNovoAlarme.Location = new System.Drawing.Point(9, 15);
            this.BtNovoAlarme.Name = "BtNovoAlarme";
            this.BtNovoAlarme.Size = new System.Drawing.Size(100, 27);
            this.BtNovoAlarme.TabIndex = 0;
            this.BtNovoAlarme.TabStop = false;
            this.BtNovoAlarme.Text = "Novo Alarme";
            this.BtNovoAlarme.UseVisualStyleBackColor = false;
            this.BtNovoAlarme.Click += new System.EventHandler(this.BtNovoAlarme_Click);
            // 
            // LbRelogio
            // 
            this.LbRelogio.AutoSize = true;
            this.LbRelogio.BackColor = System.Drawing.Color.Transparent;
            this.LbRelogio.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbRelogio.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.LbRelogio.Location = new System.Drawing.Point(658, 36);
            this.LbRelogio.Name = "LbRelogio";
            this.LbRelogio.Size = new System.Drawing.Size(104, 25);
            this.LbRelogio.TabIndex = 30;
            this.LbRelogio.Text = "00:00:00";
            // 
            // PnNovoAlarme
            // 
            this.PnNovoAlarme.BackColor = System.Drawing.Color.Transparent;
            this.PnNovoAlarme.Controls.Add(this.panel4);
            this.PnNovoAlarme.Controls.Add(this.txtHorario);
            this.PnNovoAlarme.Controls.Add(this.panel3);
            this.PnNovoAlarme.Controls.Add(this.panel2);
            this.PnNovoAlarme.Controls.Add(this.button3);
            this.PnNovoAlarme.Controls.Add(this.txtQnt);
            this.PnNovoAlarme.Controls.Add(this.groupBox2);
            this.PnNovoAlarme.Controls.Add(this.groupBox1);
            this.PnNovoAlarme.Controls.Add(this.date);
            this.PnNovoAlarme.Controls.Add(this.txtMedic);
            this.PnNovoAlarme.Cursor = System.Windows.Forms.Cursors.Default;
            this.PnNovoAlarme.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.PnNovoAlarme.Location = new System.Drawing.Point(291, 103);
            this.PnNovoAlarme.Name = "PnNovoAlarme";
            this.PnNovoAlarme.Size = new System.Drawing.Size(497, 326);
            this.PnNovoAlarme.TabIndex = 29;
            this.PnNovoAlarme.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel4.Location = new System.Drawing.Point(10, 178);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(480, 1);
            this.panel4.TabIndex = 39;
            // 
            // txtHorario
            // 
            this.txtHorario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtHorario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHorario.Font = new System.Drawing.Font("Arial", 12F);
            this.txtHorario.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.txtHorario.Location = new System.Drawing.Point(10, 160);
            this.txtHorario.Name = "txtHorario";
            this.txtHorario.Size = new System.Drawing.Size(480, 19);
            this.txtHorario.TabIndex = 38;
            this.txtHorario.Text = "Horario";
            this.txtHorario.Click += new System.EventHandler(this.txtHorario_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel3.Location = new System.Drawing.Point(10, 121);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(480, 1);
            this.panel3.TabIndex = 37;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Location = new System.Drawing.Point(10, 64);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(480, 1);
            this.panel2.TabIndex = 35;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.button3.Location = new System.Drawing.Point(198, 286);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 33);
            this.button3.TabIndex = 34;
            this.button3.Text = "Novo Alarme";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // txtQnt
            // 
            this.txtQnt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtQnt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQnt.Font = new System.Drawing.Font("Arial", 12F);
            this.txtQnt.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.txtQnt.Location = new System.Drawing.Point(10, 103);
            this.txtQnt.Name = "txtQnt";
            this.txtQnt.Size = new System.Drawing.Size(480, 19);
            this.txtQnt.TabIndex = 29;
            this.txtQnt.Text = "Quantidade";
            this.txtQnt.Click += new System.EventHandler(this.txtQnt_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdComp);
            this.groupBox2.Controls.Add(this.rdMl);
            this.groupBox2.Controls.Add(this.rdGota);
            this.groupBox2.Controls.Add(this.rdColher);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(294, 212);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 68);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dosagem";
            // 
            // rdComp
            // 
            this.rdComp.AutoSize = true;
            this.rdComp.Location = new System.Drawing.Point(109, 42);
            this.rdComp.Name = "rdComp";
            this.rdComp.Size = new System.Drawing.Size(79, 17);
            this.rdComp.TabIndex = 3;
            this.rdComp.TabStop = true;
            this.rdComp.Text = "Comprimido";
            this.rdComp.UseVisualStyleBackColor = true;
            // 
            // rdMl
            // 
            this.rdMl.AutoSize = true;
            this.rdMl.Location = new System.Drawing.Point(111, 19);
            this.rdMl.Name = "rdMl";
            this.rdMl.Size = new System.Drawing.Size(61, 17);
            this.rdMl.TabIndex = 2;
            this.rdMl.TabStop = true;
            this.rdMl.Text = "Mililitros";
            this.rdMl.UseVisualStyleBackColor = true;
            // 
            // rdGota
            // 
            this.rdGota.AutoSize = true;
            this.rdGota.Location = new System.Drawing.Point(7, 44);
            this.rdGota.Name = "rdGota";
            this.rdGota.Size = new System.Drawing.Size(48, 17);
            this.rdGota.TabIndex = 1;
            this.rdGota.TabStop = true;
            this.rdGota.Text = "Gota";
            this.rdGota.UseVisualStyleBackColor = true;
            // 
            // rdColher
            // 
            this.rdColher.AutoSize = true;
            this.rdColher.Location = new System.Drawing.Point(7, 20);
            this.rdColher.Name = "rdColher";
            this.rdColher.Size = new System.Drawing.Size(98, 17);
            this.rdColher.TabIndex = 0;
            this.rdColher.TabStop = true;
            this.rdColher.Text = "Colher de Sopa";
            this.rdColher.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdGasosa);
            this.groupBox1.Controls.Add(this.rdSemiLiquido);
            this.groupBox1.Controls.Add(this.rdLiquido);
            this.groupBox1.Controls.Add(this.rdSolido);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Location = new System.Drawing.Point(3, 212);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 68);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Forma";
            // 
            // rdGasosa
            // 
            this.rdGasosa.AutoSize = true;
            this.rdGasosa.Location = new System.Drawing.Point(111, 42);
            this.rdGasosa.Name = "rdGasosa";
            this.rdGasosa.Size = new System.Drawing.Size(61, 17);
            this.rdGasosa.TabIndex = 3;
            this.rdGasosa.TabStop = true;
            this.rdGasosa.Text = "Gasosa";
            this.rdGasosa.UseVisualStyleBackColor = true;
            // 
            // rdSemiLiquido
            // 
            this.rdSemiLiquido.AutoSize = true;
            this.rdSemiLiquido.Location = new System.Drawing.Point(111, 19);
            this.rdSemiLiquido.Name = "rdSemiLiquido";
            this.rdSemiLiquido.Size = new System.Drawing.Size(80, 17);
            this.rdSemiLiquido.TabIndex = 2;
            this.rdSemiLiquido.TabStop = true;
            this.rdSemiLiquido.Text = "Semi-Sólido";
            this.rdSemiLiquido.UseVisualStyleBackColor = true;
            // 
            // rdLiquido
            // 
            this.rdLiquido.AutoSize = true;
            this.rdLiquido.Location = new System.Drawing.Point(7, 44);
            this.rdLiquido.Name = "rdLiquido";
            this.rdLiquido.Size = new System.Drawing.Size(61, 17);
            this.rdLiquido.TabIndex = 1;
            this.rdLiquido.TabStop = true;
            this.rdLiquido.Text = "Líquido";
            this.rdLiquido.UseVisualStyleBackColor = true;
            // 
            // rdSolido
            // 
            this.rdSolido.AutoSize = true;
            this.rdSolido.Location = new System.Drawing.Point(7, 20);
            this.rdSolido.Name = "rdSolido";
            this.rdSolido.Size = new System.Drawing.Size(54, 17);
            this.rdSolido.TabIndex = 0;
            this.rdSolido.TabStop = true;
            this.rdSolido.Text = "Sólido";
            this.rdSolido.UseVisualStyleBackColor = true;
            // 
            // date
            // 
            this.date.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.date.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.date.Location = new System.Drawing.Point(10, 186);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(480, 20);
            this.date.TabIndex = 22;
            this.date.Visible = false;
            // 
            // txtMedic
            // 
            this.txtMedic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtMedic.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMedic.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedic.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.txtMedic.Location = new System.Drawing.Point(10, 45);
            this.txtMedic.Name = "txtMedic";
            this.txtMedic.Size = new System.Drawing.Size(480, 19);
            this.txtMedic.TabIndex = 0;
            this.txtMedic.Text = "Medicaento";
            this.txtMedic.Click += new System.EventHandler(this.txtMedic_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.button2.Location = new System.Drawing.Point(6, 399);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 30);
            this.button2.TabIndex = 35;
            this.button2.Text = "Ligar Alarme";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pnPerfil
            // 
            this.pnPerfil.BackColor = System.Drawing.Color.Transparent;
            this.pnPerfil.Controls.Add(this.btmostrar);
            this.pnPerfil.Controls.Add(this.panel5);
            this.pnPerfil.Controls.Add(this.comboBox1);
            this.pnPerfil.Controls.Add(this.label3);
            this.pnPerfil.Controls.Add(this.label2);
            this.pnPerfil.Controls.Add(this.label1);
            this.pnPerfil.Controls.Add(this.Lbemail);
            this.pnPerfil.Controls.Add(this.LbUsuario);
            this.pnPerfil.Controls.Add(this.LbNome);
            this.pnPerfil.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.pnPerfil.Location = new System.Drawing.Point(291, 103);
            this.pnPerfil.Name = "pnPerfil";
            this.pnPerfil.Size = new System.Drawing.Size(497, 326);
            this.pnPerfil.TabIndex = 36;
            this.pnPerfil.Visible = false;
            // 
            // btmostrar
            // 
            this.btmostrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btmostrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btmostrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmostrar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btmostrar.Location = new System.Drawing.Point(249, 149);
            this.btmostrar.Name = "btmostrar";
            this.btmostrar.Size = new System.Drawing.Size(100, 27);
            this.btmostrar.TabIndex = 8;
            this.btmostrar.TabStop = false;
            this.btmostrar.Text = "Mostrar ";
            this.btmostrar.UseVisualStyleBackColor = false;
            this.btmostrar.Click += new System.EventHandler(this.button6_Click);
            this.btmostrar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btmostrar_MouseDown);
            this.btmostrar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btmostrar_MouseUp);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.lbAlarme);
            this.panel5.Location = new System.Drawing.Point(9, 185);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(479, 134);
            this.panel5.TabIndex = 7;
            // 
            // lbAlarme
            // 
            this.lbAlarme.AutoSize = true;
            this.lbAlarme.Location = new System.Drawing.Point(4, 8);
            this.lbAlarme.Name = "lbAlarme";
            this.lbAlarme.Size = new System.Drawing.Size(13, 13);
            this.lbAlarme.TabIndex = 0;
            this.lbAlarme.Text = "a";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Alarme 1"});
            this.comboBox1.Location = new System.Drawing.Point(9, 150);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(229, 26);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.TabStop = false;
            this.comboBox1.Text = "Alarmes";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Email:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Usuário:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "Nome:";
            // 
            // Lbemail
            // 
            this.Lbemail.AutoSize = true;
            this.Lbemail.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbemail.Location = new System.Drawing.Point(72, 96);
            this.Lbemail.Name = "Lbemail";
            this.Lbemail.Size = new System.Drawing.Size(0, 18);
            this.Lbemail.TabIndex = 2;
            // 
            // LbUsuario
            // 
            this.LbUsuario.AutoSize = true;
            this.LbUsuario.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbUsuario.Location = new System.Drawing.Point(82, 64);
            this.LbUsuario.Name = "LbUsuario";
            this.LbUsuario.Size = new System.Drawing.Size(0, 18);
            this.LbUsuario.TabIndex = 1;
            // 
            // LbNome
            // 
            this.LbNome.AutoSize = true;
            this.LbNome.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbNome.Location = new System.Drawing.Point(72, 30);
            this.LbNome.Name = "LbNome";
            this.LbNome.Size = new System.Drawing.Size(0, 18);
            this.LbNome.TabIndex = 0;
            // 
            // timer
            // 
            this.timer.Interval = 10000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // Relogio
            // 
            this.Relogio.Enabled = true;
            this.Relogio.Interval = 1000;
            this.Relogio.Tick += new System.EventHandler(this.Relogio_Tick);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(122, 399);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(110, 30);
            this.button5.TabIndex = 37;
            this.button5.Text = "Desligar Alarme";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // pnConfig
            // 
            this.pnConfig.Location = new System.Drawing.Point(291, 103);
            this.pnConfig.Name = "pnConfig";
            this.pnConfig.Size = new System.Drawing.Size(497, 326);
            this.pnConfig.TabIndex = 38;
            this.pnConfig.Visible = false;
            // 
            // pnMenu
            // 
            this.pnMenu.Location = new System.Drawing.Point(291, 103);
            this.pnMenu.Name = "pnMenu";
            this.pnMenu.Size = new System.Drawing.Size(497, 326);
            this.pnMenu.TabIndex = 39;
            this.pnMenu.Visible = false;
            // 
            // Fechar
            // 
            this.Fechar.AutoSize = true;
            this.Fechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Fechar.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fechar.ForeColor = System.Drawing.Color.IndianRed;
            this.Fechar.Location = new System.Drawing.Point(769, 9);
            this.Fechar.Name = "Fechar";
            this.Fechar.Size = new System.Drawing.Size(14, 15);
            this.Fechar.TabIndex = 40;
            this.Fechar.Text = "X";
            this.Fechar.Click += new System.EventHandler(this.label4_Click);
            // 
            // Minimizar
            // 
            this.Minimizar.AutoSize = true;
            this.Minimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Minimizar.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Minimizar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Minimizar.Location = new System.Drawing.Point(748, 9);
            this.Minimizar.Name = "Minimizar";
            this.Minimizar.Size = new System.Drawing.Size(14, 15);
            this.Minimizar.TabIndex = 41;
            this.Minimizar.Text = "_";
            this.Minimizar.Click += new System.EventHandler(this.label5_Click);
            // 
            // MedMemory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(800, 441);
            this.Controls.Add(this.Minimizar);
            this.Controls.Add(this.Fechar);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.LbRelogio);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.PnNovoAlarme);
            this.Controls.Add(this.pnMenu);
            this.Controls.Add(this.pnConfig);
            this.Controls.Add(this.pnPerfil);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MedMemory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MedMemory";
            this.Load += new System.EventHandler(this.MedMemory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.panel1.ResumeLayout(false);
            this.PnNovoAlarme.ResumeLayout(false);
            this.PnNovoAlarme.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pnPerfil.ResumeLayout(false);
            this.pnPerfil.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btPerfil;
        private System.Windows.Forms.Button BtNovoAlarme;
        private System.Windows.Forms.Label LbRelogio;
        private System.Windows.Forms.Panel PnNovoAlarme;
        private System.Windows.Forms.TextBox txtQnt;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdComp;
        private System.Windows.Forms.RadioButton rdMl;
        private System.Windows.Forms.RadioButton rdGota;
        private System.Windows.Forms.RadioButton rdColher;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdGasosa;
        private System.Windows.Forms.RadioButton rdSemiLiquido;
        private System.Windows.Forms.RadioButton rdLiquido;
        private System.Windows.Forms.RadioButton rdSolido;
        private System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.TextBox txtMedic;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel pnPerfil;
        private System.Windows.Forms.Label Lbemail;
        private System.Windows.Forms.Label LbUsuario;
        private System.Windows.Forms.Label LbNome;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Timer Relogio;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtHorario;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnConfig;
        private System.Windows.Forms.Panel pnMenu;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btmostrar;
        private System.Windows.Forms.Label lbAlarme;
        private System.Windows.Forms.Label Fechar;
        private System.Windows.Forms.Label Minimizar;
    }
}

