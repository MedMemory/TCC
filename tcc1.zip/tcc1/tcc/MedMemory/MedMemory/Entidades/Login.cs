﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MedMemory.Entidades;

namespace MedMemory.Entidades
{
    public class Login
    {
        //usuario
        private string usuario;
        public void setUsuario(string _usuario)
        {
            usuario = _usuario;
        }
        public string getUsuario()
        {
            return usuario;
        }

        //senha
        private string senha;
        public void setSenha(string _senha)
        {
            senha = _senha;
        }
        public string getSenha()
        {
            return senha;
        }


        //email
        private string email;
        public void setEmail(string _email)
        {
            email = _email;
        }
        public string getEmail()
        {
            return email;
        }


        //nome
        private string nome;
        public void setNome(string _nome)
        {
            nome = _nome;
        }
        public string getNome()
        {
            return nome;
        }

        //enviar
        public string Usuario()
        {
            string lgUsuario = usuario;
            return lgUsuario;
        }
        public string Senha()
        {
            string lgSenha = senha;
            return lgSenha;
        }

        //inserir
        public void inserira()
        {
            conecta conn = new conecta();
            string sql = "INSERT into login (nome, usuario, senha, email) VALUES('" + nome + "','" + usuario + "','" + senha + "','" + email + "');";
            conn.executaCons(sql);
        }

        //verificar
        public string vereficaru()
        {
            conecta conn = new conecta();
            string sql = "select usuario from login;";
            return sql;
        }

        public string verificars()
        {
            conecta conn = new conecta();
            string sql = "select senha from login;";
            return sql;
        }

        public void veri(string usuario, string senha)
        {
            conecta conn = new conecta();
            string sql = "select * from login where usuario='@usuario' and senha='@senha';";
            
        }
    }
}
    