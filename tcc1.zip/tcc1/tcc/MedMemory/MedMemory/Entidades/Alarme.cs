﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MedMemory.Entidades;

namespace MedMemory.Entidades
{
    public class Alarme
    {
        //string nome;
        string medicamento;
        int forma;
        int dosagem;
        float quantidade;
        TimeSpan horario;
        private bool ativo;

        /*public void setNome(string _nome)
        {
            nome = _nome;
        }

        public string getNome()
        {
            return nome;
        }*/

        public void setMedicamento(string _medic)
        {
            medicamento = _medic;
        }
        public string getMedicamento()
        {
            return medicamento;
        }

        public void setForma(int _forma)
        {
            forma = _forma;
        }
        public int getForma()
        {
            return forma;
        }

        public void setDosagem(int _dose)
        {
            dosagem = _dose;
        }
        public int getDosagem()
        {
            return dosagem;
        }

        public void setQuantidade(float _quant)
        {
            quantidade = _quant;
        }
        public float getQantidade()
        {
            return quantidade;
        }

        public void setHorario(TimeSpan _horario)
        {
            horario = _horario;
        }
        public TimeSpan getHorario()
        {
            return horario;
        }

        public string usuario()
        {

            string mostrar = /*"nome: " + nome +*/
                "\nmedicamento: " + medicamento +
                "\nforma: " + forma +
                "\nquantidade: " + quantidade + " " + dosagem;
            mostrar += "\nhorario: " + horario.ToString(@"hh\:mm");
            return mostrar;
        }
        public bool getAtivo()
        {
            return ativo;
        }
        public void setAtivo(bool _Ativo)
        {
            ativo = _Ativo;
        }

        public void inserir()
        {
            string sql = "INSERT into alarme (medicamento, quantidade, horario,forma , dosagem,IdUsuario) VALUES('" + medicamento + "'," + quantidade + ",'" + horario + "'," + forma + "," + dosagem + ", 1 );";
            conecta conn = new conecta();
            conn.executaCons(sql);
        }

        public void carrega(string nome)
        {
            string sql = "SELECT * FROM alarme where medicamento ='" + nome + "'";
            conecta conn = new conecta();
            DataTable dt = conn.criaTabela(sql);
            foreach (DataRow linha in dt.Rows)
            {
                medicamento = linha["medicamento"].ToString();
                forma = Convert.ToInt16(linha["forma"].ToString());
                dosagem = Convert.ToInt16(linha["dosagem"].ToString());
                quantidade = Convert.ToSingle(linha["quantidade"].ToString());
                horario = Convert.ToDateTime(linha["horario"].ToString()).TimeOfDay;
            }

        }
        public DataTable carregatudo()
        {
            string sql = "SELECT * FROM alarme ";
            conecta conn = new conecta();
            DataTable dt = conn.criaTabela(sql);

            return dt;
        }
    }
}
