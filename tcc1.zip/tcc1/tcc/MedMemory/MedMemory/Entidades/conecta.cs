﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedMemory.Entidades
{
    class conecta
    {
        private MySqlConnection conn;
        private string server;
        private string database;
        private string uid;
        private string password;

        public conecta()
        {
            Inicializar();
            OpenConnection();
            CloseConnection();
        }

        private void Inicializar()
        {
            server = "localhost";
            database = "Medmemory";
            uid = "root";
            password = "";
            string connectionString;
            connectionString = "SERVER=" + server + ";"
                + "DATABASE=" + database + ";"
                + "UID=" + uid + ";"
                + "PASSWORD=" + password + ";";

            conn = new MySqlConnection(connectionString);
        }

        //abre connection to database
        private bool OpenConnection()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Não foi possível " +
                            "conectar ao servidor.");
                        break;
                    case 1045:
                        MessageBox.Show("Login/Senha inválidos");
                        break;
                    default:
                        MessageBox.Show("Erro no acesso ao Banco de Dados");
                        break;
                }
                return false;
            }
        }

        //Fecha connection
        private bool CloseConnection()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public DataTable criaTabela(string sql)
        {
            DataTable dt = new DataTable();
            if (this.OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataSet criaCursor(string sql)
        {
            DataSet ds = new DataSet();
            if (this.OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(ds);
            }
            return ds;
        }

        public bool executaCons(string sql)
        {
            if (this.OpenConnection() == true)
            {
                try
                {
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                    this.CloseConnection();
                    return true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro executando ação: " +
                        ex.Message);
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

    }
}