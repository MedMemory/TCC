﻿using MedMemory.Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedMemory
{
    public partial class MedMemoryLogin : Form
    {
        MedMemoryCadastro form = new MedMemoryCadastro();
        public static Login usuario;
        
        public MedMemoryLogin()
        {
            InitializeComponent();
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //fazer averificaçap
            //try
            //{
            //    usuario.veri(textusuario.Text, textsenha.Text);
            //}
            //catch(Exception e)
            //{
            //    lberro2.Visible = true;

            //}
            //if (textusuario.Text == usuario.vereficaru() && textsenha.Text == usuario.getSenha())
            //{
            //    //MedMemory.perfil = usuario;
            //    this.Dispose();
            //}
            //else
            //{
            //    lberro2.Visible = true;
            //}
        }


        //personalização
        //Login
        private void textusuario_Click(object sender, EventArgs e)
        {
            textusuario.Clear();
            textusuario.ForeColor = Color.FromArgb(38, 184, 206);
            panel7.BackColor = Color.FromArgb(38, 184, 206);
            pcusuario.Image = Properties.Resources.perfil2;

            textsenha.ForeColor = SystemColors.ButtonFace;
            panel6.BackColor = SystemColors.ButtonFace;
            pcsenha.Image = Properties.Resources.cadeado1;
        }

        private void textsenha_Click(object sender, EventArgs e)
        {
            textsenha.Clear();
            textsenha.ForeColor = Color.FromArgb(38, 184, 206);
            panel6.BackColor = Color.FromArgb(38, 184, 206);
            pcsenha.Image = Properties.Resources.cadeado2;

            textusuario.ForeColor = SystemColors.ButtonFace;
            panel7.BackColor = SystemColors.ButtonFace;
            pcusuario.Image = Properties.Resources.perfil1;
        }

        private void MedMemoryLogin_Load(object sender, EventArgs e)
        {
            form.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            form.Left += 50;
            if(form.Left >= 830)
            {
                timer1.Stop();
                this.TopMost = false;
                form.TopMost = true;
                timer2.Start();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            form.Left -= 50;
            if (form.Left <= 525)
            {
                timer2.Stop();
            }
        }
    }
}
