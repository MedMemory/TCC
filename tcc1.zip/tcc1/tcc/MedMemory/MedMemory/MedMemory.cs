﻿using MedMemory.Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedMemory
{
    public partial class MedMemory : Form
    {
        public static Login perfil;
        Alarme usuario;
        public Alarme[] pacientes;
        int i = 0;
        int tam = 1;
        public MedMemory()
        {
            InitializeComponent();
            pacientes = new Alarme[tam];
        }

        private void MedMemory_Load(object sender, EventArgs e)
        {
            MedMemoryLogin frm = new MedMemoryLogin();
            frm.ShowDialog();
            if (perfil == null)
            {
                Close();
            }
            txtHorario.Text = Convert.ToString(date.Value.TimeOfDay.ToString(@"hh\:mm"));
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            usuario = new Alarme();
            usuario.setMedicamento(txtMedic.Text);
            usuario.setQuantidade(Convert.ToSingle(txtQnt.Text));
            int forma;
            if (rdSolido.Checked == true)
            {
                forma = 1;
            }
            else if (rdLiquido.Checked == true)
            {
                forma = 2;
            }
            else if (rdSemiLiquido.Checked == true)
            {
                forma = 3;
            }
            else
            {
                forma =4;
            }
            usuario.setForma(forma);

            int dose;

            if (rdColher.Checked == true)
            {
                dose = 1;
            }
            else if (rdGota.Checked == true)
            {
                dose = 2;
            }
            else if (rdMl.Checked == true)
            {
                dose = 3;
            }
            else
            {
                dose = 4;
            }
            usuario.setDosagem(dose);

            //converter
            date.Value = Convert.ToDateTime(txtHorario.Text);


            usuario.setHorario(date.Value.TimeOfDay);
            usuario.inserir();
            

            usuario.setAtivo(true);
            timer.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer.Enabled = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            timer.Enabled = false;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            TimeSpan agora = DateTime.Now.TimeOfDay;
            for (int i = 0; i < pacientes.Length; i++)
            {
                if (pacientes[i].getHorario() <= agora && pacientes[i].getAtivo())
                {
                    string m = pacientes[i].usuario();
                    MessageBox.Show(m);
                    pacientes[i].setAtivo(false);
                }
            }
        }

        private void BtNovoAlarme_Click(object sender, EventArgs e)
        {
            if (PnNovoAlarme.Visible == false)
            {
                PnNovoAlarme.Visible = true;
                BtNovoAlarme.Text = ("Fechar");
            }
            else if (PnNovoAlarme.Visible == true)
            {
                PnNovoAlarme.Visible = false;
                BtNovoAlarme.Text = ("Novo Alarme");
            }
        }

        private void btPerfil_Click(object sender, EventArgs e)
        {
            if (pnPerfil.Visible == false)
            {
                pnPerfil.Visible = true;
                btPerfil.Text = ("Fechar");
                LbNome.Text = perfil.getNome();
                LbUsuario.Text = perfil.getUsuario();
                Lbemail.Text = perfil.getEmail();
                comboBox1.Items.Clear();
                usuario = new Alarme();
                DataTable dt = usuario.carregatudo();
                foreach (DataRow linha in dt.Rows)
                {
                    comboBox1.Items.Add(linha["medicamento"].ToString());
                   
                }
            }
            else if (pnPerfil.Visible == true)
            {
                pnPerfil.Visible = false;
                btPerfil.Text = ("Perfil");
            }
        }

        private void Relogio_Tick(object sender, EventArgs e)
        {
            LbRelogio.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void txtMedic_Click(object sender, EventArgs e)
        {
            txtMedic.Clear();
            txtMedic.ForeColor = Color.FromArgb(38, 184, 206);
            panel2.BackColor = Color.FromArgb(38, 184, 206);

            txtQnt.ForeColor = SystemColors.ButtonFace;
            panel3.BackColor = SystemColors.ButtonFace;
            txtHorario.ForeColor = SystemColors.ButtonFace;
            panel4.BackColor = SystemColors.ButtonFace;
        }

        private void txtQnt_Click(object sender, EventArgs e)
        {
            txtQnt.Clear();
            txtQnt.ForeColor = Color.FromArgb(38, 184, 206);
            panel3.BackColor = Color.FromArgb(38, 184, 206);

            txtMedic.ForeColor = SystemColors.ButtonFace;
            panel2.BackColor = SystemColors.ButtonFace;
            txtHorario.ForeColor = SystemColors.ButtonFace;
            panel4.BackColor = SystemColors.ButtonFace;
        }

        private void txtHorario_Click(object sender, EventArgs e)
        {
            txtHorario.Clear();
            txtHorario.ForeColor = Color.FromArgb(38, 184, 206);
            panel4.BackColor = Color.FromArgb(38, 184, 206);

            txtMedic.ForeColor = SystemColors.ButtonFace;
            panel2.BackColor = SystemColors.ButtonFace;
            txtQnt.ForeColor = SystemColors.ButtonFace;
            panel3.BackColor = SystemColors.ButtonFace;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            usuario.carrega(comboBox1.Text);
            lbAlarme.Text = usuario.usuario();
            /*  string mostrar = "";
              for (int i = 0; i < pacientes.Length; i++)
              {
                  if (pacientes[i].getMedicamento() == comboBox1.Text)
                  {
                      mostrar = /*"nome: " + nome +
                     "\nmedicamento: " + pacientes[i].getMedicamento() +
                     "\nforma: " + pacientes[i].getForma() +
                     "\nquantidade: " + pacientes[i].getQantidade() + " " + pacientes[i].getDosagem();
                      mostrar += "\nhorario: " + pacientes[i].getHorario().ToString(@"hh\:mm");
                  }
              }
              lbAlarme.Text = mostrar;*/
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void btmostrar_MouseDown(object sender, MouseEventArgs e)
        {
            btmostrar.ForeColor = Color.FromName("ActiveBorder");
        }

        private void btmostrar_MouseUp(object sender, MouseEventArgs e)
        {
            btmostrar.ForeColor = Color.FromArgb(34, 36, 49);
        }
    }
}
