﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoverForm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
         

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //frm.Left += 50;
            //if (frm.Left >= 830)
            //{
            //    timer1.Stop();
            //    this.TopMost = false;
            //    frm.TopMost = true;
            //    timer2.Start();
            //}

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //frm.Left -= 50;
            //if (frm.Left <= 525)
            //{

            //    timer2.Stop();
            //}

        }
    }
}
