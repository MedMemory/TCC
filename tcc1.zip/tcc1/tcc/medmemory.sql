create database Medmemory;
use Medmemory;

create table login(
IdUsuario int not null auto_increment primary key,
nome varchar (40) not null ,
usuario varchar (20) not null ,
senha varchar (10) not null,
email varchar (40) not null
);

select * from login;
insert into login values (null,'rogerio','legal123','123','w@gmail.com');

create table alarme(
IdAlarme int not null auto_increment not null primary key,
medicamento varchar(50) ,
quantidade varchar(10),
horario time not null,
forma int not null,
dosagem int not null,
IdUsuario int 
);

insert into alarme VALUES(null,'arroz','12','11:55',1,2,1);
select * from alarme;